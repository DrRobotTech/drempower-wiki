﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO.Ports;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

namespace can_config
{
    public partial class Configform : Form
    {
        [DllImport("kernel32.dll")]                                             //延时用
        static extern uint GetTickCount();

        public string PortNum;
        public Configform()
        {
            InitializeComponent();
        }

        private void Configform_Load(object sender, EventArgs e)
        {
            Rectangle rect = new Rectangle();
            rect = Screen.GetWorkingArea(this);
            Point p = new Point((rect.Width - this.Width) / 2, (rect.Height - this.Height) / 2);
            this.Location = p;                                                          //设置初始位置    


            //初始化显示
            cmb_BaudRate.SelectedIndex = 3;         //串口波特率9600  
            cmb_StopBits.SelectedIndex = 0;         //停止位1          
            cmb_Parity.SelectedIndex = 0;           //无校验           
            cmb_trans_mode.SelectedIndex = 0;       //转换模式
            cmb_sendtype.SelectedIndex = 1;         //发送报文类型 扩展帧
            cmb_idpostion.SelectedIndex = 0;
            cmb_idlen.SelectedIndex = 0;

            chk_biaozhun.Checked = true;            //接收标准帧
            chk_kuozhan.Checked = true;             //接收扩展帧
            chk_feiyuancheng.Checked = true;        //接收非远程帧
            chk_yuancheng.Checked = true;           //接收远程帧
        }

        /// <summary>
        /// 毫秒延时
        /// </summary>
        /// <param name="ms">毫秒数</param>
        public static void Delay(uint ms)                                              
        {
            uint start = GetTickCount();
            while (GetTickCount() - start < ms)
            { Application.DoEvents(); }
        }

        //获取当前配置按钮
        private void btn_getconfig_Click(object sender, EventArgs e)
        {
            try
            {
                if (combo_uart.Text == "") { MessageBox.Show("未选择串口"); return; }
                btn_getconfig.Enabled = false;
                btn_restore.Enabled = false;
                btn_config.Enabled = false;
                mycomm = new SerialPort(combo_uart.Text);
                mycomm.BaudRate = 9600;
                mycomm.DtrEnable = true;             //打开DTR
                mycomm.DataBits = 8;
                mycomm.Parity = Parity.None;
                mycomm.StopBits = StopBits.One;
                mycomm.Handshake = Handshake.None;
                mycomm.RtsEnable = false;               

                try { mycomm.Open(); }
                catch
                {
                    MessageBox.Show("打开串口失败");
                    btn_getconfig.Enabled = true;
                    btn_restore.Enabled = true;
                    btn_config.Enabled = true;
                    return;
                }
                Delay(100);
                readconfig();                       //读取配置信息
                mycomm.Close();
                btn_getconfig.Enabled = true;
                btn_restore.Enabled = true;
                btn_config.Enabled = true;
            }
            catch
            {
                MessageBox.Show("失败");
                btn_getconfig.Enabled = true;
                btn_restore.Enabled = true;
                btn_config.Enabled = true;
            }
        }

        //恢复默认按钮
        private void btn_restore_Click(object sender, EventArgs e)
        {
            try
            {
                if (combo_uart.Text == "") { MessageBox.Show("未选择串口"); }
                btn_getconfig.Enabled = false;
                btn_restore.Enabled = false;
                btn_config.Enabled = false;
                mycomm = new SerialPort(combo_uart.Text);
                mycomm.BaudRate = 9600;
                mycomm.DtrEnable = true;             //打开DTR
                try { mycomm.Open(); }
                catch
                {
                    MessageBox.Show("打开串口失败");
                    btn_getconfig.Enabled = true;
                    btn_restore.Enabled = true;
                    btn_config.Enabled = true;
                    return;
                }
                Delay(50);
                mycomm.Write("\n");
                Delay(50);
                mycomm.Write("d");
                Delay(5);
                mycomm.Write("e");
                Delay(5);
                mycomm.Write("f");
                Delay(5);
                mycomm.Write("\n");

                Delay(1500);
                readconfig();
                mycomm.Close();
                btn_getconfig.Enabled = true;
                btn_restore.Enabled = true;
                btn_config.Enabled = true;
            }
            catch
            {
                btn_getconfig.Enabled = true;
                btn_restore.Enabled = true;
                btn_config.Enabled = true;
            }
        }

        //修改配置按钮
        private void btn_config_Click(object sender, EventArgs e)
        {
            try
            {                
                if (combo_uart.Text == "") { MessageBox.Show("未选择串口"); return; }
                try
                {
                    if (cmb_trans_mode.SelectedIndex == 2 && txt_packettime.Text == "0")
                    {
                        MessageBox.Show("透传带标识模式必须设置分包间隔");
                        return;
                    }
                    if (cmb_trans_mode.SelectedIndex == 3 && txt_packettime.Text == "0")
                    {
                        //MessageBox.Show("MODBUS模式分包间隔为0表示使用协议规定的3.5字符分包间隔");
                        //return;
                    }
                }
                catch 
                {
                    MessageBox.Show("分包间隔输入有误");
                    return;
                }
                if (!chk_filter0.Checked && !chk_filter1.Checked && !chk_filter2.Checked && !chk_filter3.Checked && !chk_filter4.Checked && !chk_filter5.Checked)
                {
                    MessageBox.Show("至少需要使能一个过滤器");
                }
                btn_getconfig.Enabled = false;
                btn_restore.Enabled = false;
                btn_config.Enabled = false;
                mycomm = new SerialPort(combo_uart.Text);
                mycomm.BaudRate = 9600;
                mycomm.DtrEnable = true;             //打开DTR
                try { mycomm.Open(); }
                catch
                {
                    MessageBox.Show("打开串口失败");
                    btn_getconfig.Enabled = true;
                    btn_restore.Enabled = true;
                    btn_config.Enabled = true;
                    return;
                }
                if (setconfig()) { MessageBox.Show("发送成功，请获取当前状态检查是否配置成功"); }
                mycomm.Close();
                btn_getconfig.Enabled = true;
                btn_restore.Enabled = true;
                btn_config.Enabled = true;
            }
            catch
            {
                MessageBox.Show("配置出错,请检查输入");
                btn_getconfig.Enabled = true;
                btn_restore.Enabled = true;
                btn_config.Enabled = true;
            }
        }

        //读取设置
        private void readconfig()
        {
            Delay(50);
            mycomm.Write("\n");
            Delay(50);
            //打开回显
            mycomm.Write("echo 1\n");
          
            Delay(100);
            mycomm.DiscardInBuffer();            //清接收缓存   
            mycomm.Write("stat\n");
                       
            Delay(1500);
            string statstring = mycomm.ReadExisting();          
            string pattern = @"stat([\s\S]*?)>";
            if (!Regex.IsMatch(statstring, pattern))        //检测是否收全了配置信息
            {
                MessageBox.Show("读取配置信息失败"); mycomm.Close(); return;
            }
            mycomm.Close();
            string pattern_f_id0 = @"\(f_id0\)\s*filter:\s*(\S+)\s*mask:\s*(\S+)\s*enable:\s*(\S+)";
            string pattern_f_id1 = @"\(f_id1\)\s*filter:\s*(\S+)\s*mask:\s*(\S+)\s*enable:\s*(\S+)";
            string pattern_f_id2 = @"\(f_id2\)\s*filter:\s*(\S+)\s*mask:\s*(\S+)\s*enable:\s*(\S+)";
            string pattern_f_id3 = @"\(f_id3\)\s*filter:\s*(\S+)\s*mask:\s*(\S+)\s*enable:\s*(\S+)";
            string pattern_f_id4 = @"\(f_id4\)\s*filter:\s*(\S+)\s*mask:\s*(\S+)\s*enable:\s*(\S+)";
            string pattern_f_id5 = @"\(f_id5\)\s*filter:\s*(\S+)\s*mask:\s*(\S+)\s*enable:\s*(\S+)";
            
            string pattern_f_id = @"\(f_id\)\t\tfilter: (.*?)\r\n";          
            string pattern_f_mask = @"\(f_id\)\s*mask: (.*?)\r\n";

            string pattern_f_type = @"\(f_type\)\s*(.*?)\r\n";
            string pattern_f_rm = @"\(f_rm\)\s*(.*?)\r\n";
            string pattern_uart_b = @"\(uart_b\)\s*uart baud: (.*?)\r\n";
            string pattern_uart_stop_bit = @"\(uart_stop_bit\)\s*uart stop: (.*?) bit\r\n";
            string pattern_uart_check_bit = @"\(uart_check_bit\)\s*uart check: (.*?)\r\n";
            string pattern_can_b = @"\(can_b\)\s+can baud: (.*?)k\r\n";
            string pattern_mod = @"\(mod\)\s*(.*?):(.*?)\r\n";
            string pattern_t_type = @"\(t_type\)\s*(.*?)\r\n";
            string pattern_t_id = @"\(t_id\)\s*send id: (.*?)\r\n";
            string pattern_t_pkt_time = @"\(t_pkt_time\)\s*pkt divided time: (.*?)ms\r\n";
            string pattern_trans_addinfo = @"\(trans_addinfo\)\s*(.*?)\r\n";
            string pattern_trans_addid = @"\(trans_addid\)\s*(.*?)\r\n";
            string pattern_idpostion = @"\(idpostion\)\s*postion: (.*?)\r\n";
            string pattern_idlen = @"\(idlength\)\s*len: (.*?)\r\n";
            string pattern_firmware = @"firmware version:\s*(.*?)\r\n";

            Match match_f_id0 = Regex.Match(statstring, pattern_f_id0);
            Match match_f_id1 = Regex.Match(statstring, pattern_f_id1);
            Match match_f_id2 = Regex.Match(statstring, pattern_f_id2);
            Match match_f_id3 = Regex.Match(statstring, pattern_f_id3);
            Match match_f_id4 = Regex.Match(statstring, pattern_f_id4);
            Match match_f_id5 = Regex.Match(statstring, pattern_f_id5);
            
            Match match_f_id = Regex.Match(statstring, pattern_f_id);           
            Match match_f_mask = Regex.Match(statstring, pattern_f_mask);
            Match match_f_type = Regex.Match(statstring, pattern_f_type);
            Match match_f_rm = Regex.Match(statstring, pattern_f_rm);
            Match match_uart_b = Regex.Match(statstring, pattern_uart_b);
            Match match_uart_stop_bit = Regex.Match(statstring, pattern_uart_stop_bit);
            Match match_uart_check_bit = Regex.Match(statstring, pattern_uart_check_bit);
            Match match_can_b = Regex.Match(statstring, pattern_can_b);
            Match match_mod = Regex.Match(statstring, pattern_mod);
            Match match_t_type = Regex.Match(statstring, pattern_t_type);
            Match match_t_id = Regex.Match(statstring, pattern_t_id);
            Match match_t_pkt_time = Regex.Match(statstring, pattern_t_pkt_time);
            Match match_trans_addinfo = Regex.Match(statstring, pattern_trans_addinfo);
            Match match_trans_addid = Regex.Match(statstring, pattern_trans_addid);
            Match match_idpostion = Regex.Match(statstring, pattern_idpostion);
            Match match_idlen = Regex.Match(statstring, pattern_idlen);
            Match match_pattern_firmware = Regex.Match(statstring, pattern_firmware);
            //填入过滤器0信息
            txt_filter_id0.Text = match_f_id0.Groups[1].Value;
            txt_filter_mask0.Text = match_f_id0.Groups[2].Value;
            if (match_f_id0.Groups[3].Value == "1")
            {
                chk_filter0.Checked = true;
            }
            else
            {
                chk_filter0.Checked = false;
            }
            //填入过滤器1信息
            txt_filter_id1.Text = match_f_id1.Groups[1].Value;
            txt_filter_mask1.Text = match_f_id1.Groups[2].Value;
            if (match_f_id1.Groups[3].Value == "1")
            {
                chk_filter1.Checked = true;
            }
            else
            {
                chk_filter1.Checked = false;
            }
            //填入过滤器2信息
            txt_filter_id2.Text = match_f_id2.Groups[1].Value;
            txt_filter_mask2.Text = match_f_id2.Groups[2].Value;
            if (match_f_id2.Groups[3].Value == "1")
            {
                chk_filter2.Checked = true;
            }
            else
            {
                chk_filter2.Checked = false;
            }
            //填入过滤器3信息
            txt_filter_id3.Text = match_f_id3.Groups[1].Value;
            txt_filter_mask3.Text = match_f_id3.Groups[2].Value;
            if (match_f_id3.Groups[3].Value == "1")
            {
                chk_filter3.Checked = true;
            }
            else
            {
                chk_filter3.Checked = false;
            }
            //填入过滤器4信息
            txt_filter_id4.Text = match_f_id4.Groups[1].Value;
            txt_filter_mask4.Text = match_f_id4.Groups[2].Value;
            if (match_f_id4.Groups[3].Value == "1")
            {
                chk_filter4.Checked = true;
            }
            else
            {
                chk_filter4.Checked = false;
            }
            //填入过滤器5信息
            txt_filter_id5.Text = match_f_id5.Groups[1].Value;
            txt_filter_mask5.Text = match_f_id5.Groups[2].Value;
            if (match_f_id5.Groups[3].Value == "1")
            {
                chk_filter5.Checked = true;
            }
            else
            {
                chk_filter5.Checked = false;
            }
            if (match_f_id0.Groups[3].Value == "0" && match_f_id1.Groups[3].Value == "0" && match_f_id2.Groups[3].Value == "0" && match_f_id3.Groups[3].Value == "0" && match_f_id4.Groups[3].Value == "0" && match_f_id5.Groups[3].Value == "0")
            {
                chk_filter0.Checked = true;
            }

            if (match_f_id0.Groups[1].Value == "")
            {
                //旧版接收过滤ID、MASK
                txt_filter_id0.Text = match_f_id.Groups[1].Value;
                txt_filter_mask0.Text = match_f_mask.Groups[1].Value;
                chk_filter0.Checked = true; 
            }                     
        
            switch (match_f_type.Groups[1].Value)                                   //接收标准、扩展帧                
            {
                case "receive std frame":
                    {
                        chk_biaozhun.Checked = true;
                        chk_kuozhan.Checked = false;
                        break;
                    }
                case "receive ext frame":
                    {
                        chk_biaozhun.Checked = false;
                        chk_kuozhan.Checked = true;
                        break;
                    }
                case "receive std and ext frame":
                    {
                        chk_biaozhun.Checked = true;
                        chk_kuozhan.Checked = true;
                        break;
                    }
                default: break;
            }
            switch (match_f_rm.Groups[1].Value)                                     //接收远程、非远程帧
            {
                case "receive normal frame":
                    {
                        chk_feiyuancheng.Checked = true;
                        chk_yuancheng.Checked = false;
                        break;
                    }
                case "receive remote frame":
                    {
                        chk_feiyuancheng.Checked = false;
                        chk_yuancheng.Checked = true;
                        break;
                    }
                case "receive normal and remote frame":
                    {
                        chk_feiyuancheng.Checked = true;
                        chk_yuancheng.Checked = true;
                        break;
                    }
                default: break;
            }
            cmb_BaudRate.Text = match_uart_b.Groups[1].Value;                       //串口波特率
            
            cmb_StopBits.Text = match_uart_stop_bit.Groups[1].Value;                //停止位
            switch (match_uart_check_bit.Groups[1].Value)                           //校验位
            {
                case "no check":
                    {
                        cmb_Parity.SelectedIndex = 0;
                        break;
                    }
                case "odd check":
                    {
                        cmb_Parity.SelectedIndex = 1;
                        break;
                    }
                case "even check":
                    {
                        cmb_Parity.SelectedIndex = 2;
                        break;
                    }
                default: break;
            }
            txt_CAN_B.Text = match_can_b.Groups[1].Value;                           //CAN波特率
            label_firmware_version_val.Text = match_pattern_firmware.Groups[1].Value;
            
            try
            {
                cmb_trans_mode.SelectedIndex = Convert.ToInt32(match_mod.Groups[1].Value);
            }
            catch
            {
                cmb_trans_mode.SelectedIndex = 0;
            }

            switch (cmb_trans_mode.SelectedIndex)
            {
                case 0:     //透传
                {
                    if (match_t_type.Groups[1].Value == "send std frame default")       //发送标准帧、扩展帧
                    { cmb_sendtype.SelectedIndex = 0; }
                    if (match_t_type.Groups[1].Value == "send ext frame default")
                    { cmb_sendtype.SelectedIndex = 1; }
                    txt_sendid.Text = match_t_id.Groups[1].Value;                       //发送报文ID
                    txt_packettime.Text = match_t_pkt_time.Groups[1].Value;             //分包间隔     
                    if (match_trans_addinfo.Groups[1].Value == "open")
                    {
                        chk_addinfo.Checked = true;
                    }
                    else
                    {
                        chk_addinfo.Checked = false;
                    }
                    if (match_trans_addid.Groups[1].Value == "open")
                    {
                        chk_addid.Checked = true;
                    }
                    else
                    {
                        chk_addid.Checked = false;
                    }
                    break;
                }
                case 1:     //包模式
                {
                    break;
                }
                case 2:     //透传+ID
                {
                    if (match_t_type.Groups[1].Value == "send std frame default")       //发送标准帧、扩展帧
                    { cmb_sendtype.SelectedIndex = 0; }
                    if (match_t_type.Groups[1].Value == "send ext frame default")
                    { cmb_sendtype.SelectedIndex = 1; }
                    txt_packettime.Text = match_t_pkt_time.Groups[1].Value;             //分包间隔  
                    cmb_idpostion.Text = match_idpostion.Groups[1].Value;
                    cmb_idlen.Text = match_idlen.Groups[1].Value;
                    break;
                }
                case 3:
                {
                    txt_packettime.Text = match_t_pkt_time.Groups[1].Value;             //分包间隔     
                    if (txt_packettime.Text == "0")
                    {
                        chk_modbus_def_pkttime.Checked = false;
                    }
                    else
                    {
                        chk_modbus_def_pkttime.Checked = true;
                    }
                    break;
                }
            }
            return;
        }

        //发送设置
        private bool setconfig()        
        {
            try
            {
                Delay(50);
                //关闭回显
                mycomm.Write("echo 0\n");
                //mycomm.Write("e");
                //Delay(5);
                //mycomm.Write("c");
                //Delay(5);
                //mycomm.Write("h");
                //Delay(5);
                //mycomm.Write("o");
                //Delay(5);
                //mycomm.Write(" ");
                //Delay(5);
                //mycomm.Write("0");
                //Delay(5);
                //mycomm.Write("\n");
                Delay(50);
                //串口波特率
                mycomm.Write("uart_b " + cmb_BaudRate.Text + "\n");
                Delay(50);
                //CAN波特率
                mycomm.Write("can_b " + txt_CAN_B.Text + "\n");
                Delay(50);
                //停止位
                mycomm.Write("uart_stop_bit " + cmb_StopBits.Text + "\n");
                Delay(50);
                //校验位
                mycomm.Write("uart_check_bit " + cmb_Parity.SelectedIndex + "\n");
                Delay(50);
                
                //模式
                switch (cmb_trans_mode.SelectedIndex)
                {
                    case 0: //透传模式
                    {
                        mycomm.Write("mod 0\n");
                        Delay(50);
                        //发送ID
                        mycomm.Write("t_id " + txt_sendid.Text + "\n");
                        Delay(50);
                        //发送类型
                        mycomm.Write("t_type " + cmb_sendtype.SelectedIndex + "\n");
                        Delay(50);
                        //发送分包间隔
                        mycomm.Write("t_pkt_time " + txt_packettime.Text + "\n");
                        Delay(50);

                        //是否添加ID
                        if (chk_addid.Checked)
                        {
                            mycomm.Write("trans_addid 1\n");
                        }
                        else
                        {
                            mycomm.Write("trans_addid 0\n");
                        }
                        Delay(50);
                        //是否添加帧类型
                        if (chk_addinfo.Checked)
                        {
                            mycomm.Write("trans_addinfo 1\n");
                        }
                        else
                        {
                            mycomm.Write("trans_addinfo 0\n");
                        }
                        Delay(50);
                        break;
                    }
                    case 1:
                    {
                         mycomm.Write("mod 1\n");
                        Delay(50);
                        break;
                    }
                    case 2:
                    {
                        mycomm.Write("mod 2\n");
                        Delay(50);
                        //发送类型
                        mycomm.Write("t_type " + cmb_sendtype.SelectedIndex + "\n");
                        Delay(50);
                        mycomm.Write("idpostion " + cmb_idpostion.Text + "\n");
                        Delay(50);
                        mycomm.Write("idlength " + cmb_idlen.Text + "\n");
                        Delay(50);
                        //发送分包间隔
                        mycomm.Write("t_pkt_time " + txt_packettime.Text + "\n");
                        Delay(50);
                        break;
                    }
                    case 3:
                    {
                        mycomm.Write("mod 3\n");
                        Delay(50);
                        //发送分包间隔
                        if (!chk_modbus_def_pkttime.Checked)
                        {
                            mycomm.Write("t_pkt_time 0\n");  
                        }
                        else
                        {
                            mycomm.Write("t_pkt_time " + txt_packettime.Text + "\n");
                        }
                        Delay(50);
                        break;
                    }
                    case 4:
                    {
                        mycomm.Write("mod 4\n");
                        Delay(50);
                        break;
                    }
                }
                
              
                //远程非远程帧
                if (chk_feiyuancheng.Checked && !chk_yuancheng.Checked)
                {
                    mycomm.Write("f_rm 0\n");
                    Delay(50);
                }
                else if (!chk_feiyuancheng.Checked && chk_yuancheng.Checked)
                {
                    mycomm.Write("f_rm 1\n");
                    Delay(50);
                }
                else
                {
                    mycomm.Write("f_rm 2\n");
                    Delay(50);
                }
                //标准帧、扩展帧
                if (chk_biaozhun.Checked && !chk_kuozhan.Checked)
                {
                    mycomm.Write("f_type 0\n");
                    Delay(50);
                }
                else if (!chk_biaozhun.Checked && chk_kuozhan.Checked)
                {
                    mycomm.Write("f_type 1\n");
                    Delay(50);
                }
                else
                {
                    mycomm.Write("f_type 2\n");
                    Delay(50);
                }
                //兼容旧版                
                mycomm.Write("f_id " + txt_filter_id0.Text + "," + txt_filter_mask0.Text + "\n");
                Delay(50);
                //新版过滤
                if (chk_filter0.Checked)
                {
                    mycomm.Write("f_id0 " + txt_filter_id0.Text + "," + txt_filter_mask0.Text + ",1\n");
                }
                else
                {
                    mycomm.Write("f_id0 " + txt_filter_id0.Text + "," + txt_filter_mask0.Text + ",0\n");
                }                
                Delay(100);
                if (chk_filter1.Checked)
                {
                    mycomm.Write("f_id1 " + txt_filter_id1.Text + "," + txt_filter_mask1.Text + ",1\n");
                }
                else
                {
                    mycomm.Write("f_id1 " + txt_filter_id1.Text + "," + txt_filter_mask1.Text + ",0\n");
                }
                Delay(100);
                if (chk_filter2.Checked)
                {
                    mycomm.Write("f_id2 " + txt_filter_id2.Text + "," + txt_filter_mask2.Text + ",1\n");
                }
                else
                {
                    mycomm.Write("f_id2 " + txt_filter_id2.Text + "," + txt_filter_mask2.Text + ",0\n");
                }
                Delay(100);
                if (chk_filter3.Checked)
                {
                    mycomm.Write("f_id3 " + txt_filter_id3.Text + "," + txt_filter_mask3.Text + ",1\n");
                }
                else
                {
                    mycomm.Write("f_id3 " + txt_filter_id3.Text + "," + txt_filter_mask3.Text + ",0\n");
                }
                Delay(100);
                if (chk_filter4.Checked)
                {
                    mycomm.Write("f_id4 " + txt_filter_id4.Text + "," + txt_filter_mask4.Text + ",1\n");
                }
                else
                {
                    mycomm.Write("f_id4 " + txt_filter_id4.Text + "," + txt_filter_mask4.Text + ",0\n");
                }
                Delay(100);
                if (chk_filter5.Checked)
                {
                    mycomm.Write("f_id5 " + txt_filter_id5.Text + "," + txt_filter_mask5.Text + ",1\n");
                }
                else
                {
                    mycomm.Write("f_id5 " + txt_filter_id5.Text + "," + txt_filter_mask5.Text + ",0\n");
                }
                Delay(100);


                //打开回显
                //mycomm.Write("e");
                //Delay(5);
                //mycomm.Write("c");
                //Delay(5);
                //mycomm.Write("h");
                //Delay(5);
                //mycomm.Write("o");
                //Delay(5);
                //mycomm.Write(" ");
                //Delay(5);
                //mycomm.Write("1");
                //Delay(5);
                //mycomm.Write("\n");
                mycomm.Write("echo 1\n");
                Delay(50);
                return true;
            }
            catch
            {
                MessageBox.Show("配置失败");
                return false; }
        }
       
        //关闭窗口事件
        private void Configform_FormClosing(object sender, FormClosingEventArgs e)
        {
            mycomm.Close();
        }

        //串口下拉框点击事件（搜索串口）
        private void combo_uart_Click(object sender, EventArgs e)
        {
            combo_uart.Items.Clear();
            string[] ports = SerialPort.GetPortNames();             //搜索串口
            Array.Sort(ports);
            combo_uart.Items.AddRange(ports);
        }
        
        //CAN发送类型下拉框选择事件（设置可选ID长度）
        private void combo_sendtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            string temp = cmb_idlen.Text;
            if (cmb_sendtype.SelectedIndex == 0)
            {
                cmb_idlen.Items.Clear();
                string[] array = { "1", "2" };
                cmb_idlen.Items.AddRange(array);
            }
            else
            {
                cmb_idlen.Items.Clear();
                string[] array = { "1", "2", "3", "4" };
                cmb_idlen.Items.AddRange(array);
            }
            try
            {
                cmb_idlen.Text = temp;
                if (cmb_idlen.SelectedIndex == -1)
                {
                    cmb_idlen.SelectedIndex = 0;
                }
            }
            catch
            {
              
            }
        }

        //转换模式下拉框选择事件
        private void cmb_trans_mode_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmb_trans_mode.SelectedIndex)
            {
                case 0:
                {
                    groupBox_trans.Visible = true;
                    groupBox_transaddid.Visible = false;
                    groupBox_empty.Visible = false;
                    groupBox_modbus_Setting.Visible = false;

                    txt_sendid.Enabled = true;
                    cmb_sendtype.Enabled = true;
                    txt_packettime.Enabled = true;
                    break;
                }
                case 2:
                {
                    groupBox_trans.Visible = false;
                    groupBox_transaddid.Visible = true;
                    groupBox_empty.Visible = false;
                    groupBox_modbus_Setting.Visible = false;

                    txt_sendid.Enabled = false;
                    cmb_sendtype.Enabled = true;
                    txt_packettime.Enabled = true;
                    break;
                }
                case 3:
                {
                    groupBox_trans.Visible = false;
                    groupBox_transaddid.Visible = false;
                    groupBox_empty.Visible = false;
                    groupBox_modbus_Setting.Visible = true;

                    txt_sendid.Enabled = false;
                    cmb_sendtype.Enabled = false;
                    if (!chk_modbus_def_pkttime.Checked)
                    {
                        txt_packettime.Enabled = false;
                    }
                    else
                    {
                        txt_packettime.Enabled = true;
                    }
                    break;
                }
                default:
                {
                    groupBox_trans.Visible = false;
                    groupBox_transaddid.Visible = false;
                    groupBox_empty.Visible = true;
                    groupBox_modbus_Setting.Visible = false;

                    txt_sendid.Enabled = false;
                    cmb_sendtype.Enabled = false;
                    txt_packettime.Enabled = false;
                    break;
                }
            }
        }

        //CAN波特率输入结束事件
        private void txt_CAN_B_Leave(object sender, EventArgs e)
        {
            check_canb();
        }

        //CAN波特率输入修改事件
        private void txt_CAN_B_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                check_canb();
            }
        }

        //检查CAN波特率
        private void check_canb()
        {
            try
            {
                double can_b_set = Convert.ToDouble(txt_CAN_B.Text);
                if (can_b_set > 1000)
                {
                    can_b_set = 1000;
                }
                if (can_b_set >= 20 && can_b_set < 1000)
                {
                    can_b_set = (1000 / Math.Round(1000 / can_b_set));
                }
                if (can_b_set >= 5 && can_b_set < 20)
                {
                    can_b_set = (250 / Math.Round(250 / can_b_set));
                }
                if (can_b_set < 5)
                {
                    can_b_set = 5;
                }
                txt_CAN_B.Text = (can_b_set - 0.05).ToString("#0.0");       //向下取整保留一位小数
            }
            catch
            {
                MessageBox.Show("CAN_B输入错误");
            }
        }

        //发送ID输入结束事件（检查）
        private void txt_sendid_Leave(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt64(txt_sendid.Text, 16) > 0xFFFFFFFF)
                {
                    MessageBox.Show("发送报文ID输入有误");
                    txt_sendid.Text = "00000000";
                }
            }
            catch
            {
                MessageBox.Show("发送报文ID输入有误");
                txt_sendid.Text = "00000000";
            }
        }

        //分包间隔输入结束事件（检查）
        private void txt_packettime_Leave(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(txt_packettime.Text) > 255 || Convert.ToInt32(txt_packettime.Text) < 0)
                {
                    txt_packettime.Text = "0";
                }
            }
            catch
            {
                txt_packettime.Text = "0";
            }
        }       

        //接收标准帧勾选框状态改变事件
        private void check_biaozhun_CheckedChanged(object sender, EventArgs e)
        {
            if (!chk_biaozhun.Checked) 
            {
                chk_kuozhan.Checked = true; 
            }
            if (chk_biaozhun.Checked && chk_kuozhan.Checked) 
            {
                txt_filter_id0.Enabled = false;
                txt_filter_id1.Enabled = false;
                txt_filter_id2.Enabled = false;
                txt_filter_id3.Enabled = false;
                txt_filter_id4.Enabled = false;
                txt_filter_id5.Enabled = false;
                txt_filter_mask0.Enabled = false;
                txt_filter_mask1.Enabled = false;
                txt_filter_mask2.Enabled = false;
                txt_filter_mask3.Enabled = false;
                txt_filter_mask4.Enabled = false;
                txt_filter_mask5.Enabled = false;
                chk_filter0.Enabled = false;
                chk_filter1.Enabled = false;
                chk_filter2.Enabled = false;
                chk_filter3.Enabled = false;
                chk_filter4.Enabled = false;
                chk_filter5.Enabled = false;
            }
            else 
            {
                txt_filter_id0.Enabled = true;
                txt_filter_id1.Enabled = true;
                txt_filter_id2.Enabled = true;
                txt_filter_id3.Enabled = true;
                txt_filter_id4.Enabled = true;
                txt_filter_id5.Enabled = true;
                txt_filter_mask0.Enabled = true;
                txt_filter_mask1.Enabled = true;
                txt_filter_mask2.Enabled = true;
                txt_filter_mask3.Enabled = true;
                txt_filter_mask4.Enabled = true;
                txt_filter_mask5.Enabled = true;
                chk_filter0.Enabled = true;
                chk_filter1.Enabled = true;
                chk_filter2.Enabled = true;
                chk_filter3.Enabled = true;
                chk_filter4.Enabled = true;
                chk_filter5.Enabled = true;
            }
        }

        //接收扩展帧勾选框状态改变事件
        private void check_kuozhan_CheckedChanged(object sender, EventArgs e)
        {
            if (!chk_biaozhun.Checked) 
            {
                chk_kuozhan.Checked = true; 
            }
            if (chk_biaozhun.Checked && chk_kuozhan.Checked)
            {
                txt_filter_id0.Enabled = false;
                txt_filter_id1.Enabled = false;
                txt_filter_id2.Enabled = false;
                txt_filter_id3.Enabled = false;
                txt_filter_id4.Enabled = false;
                txt_filter_id5.Enabled = false;
                txt_filter_mask0.Enabled = false;
                txt_filter_mask1.Enabled = false;
                txt_filter_mask2.Enabled = false;
                txt_filter_mask3.Enabled = false;
                txt_filter_mask4.Enabled = false;
                txt_filter_mask5.Enabled = false;
                chk_filter0.Enabled = false;
                chk_filter1.Enabled = false;
                chk_filter2.Enabled = false;
                chk_filter3.Enabled = false;
                chk_filter4.Enabled = false;
                chk_filter5.Enabled = false;
            }
            else
            {
                txt_filter_id0.Enabled = true;
                txt_filter_id1.Enabled = true;
                txt_filter_id2.Enabled = true;
                txt_filter_id3.Enabled = true;
                txt_filter_id4.Enabled = true;
                txt_filter_id5.Enabled = true;
                txt_filter_mask0.Enabled = true;
                txt_filter_mask1.Enabled = true;
                txt_filter_mask2.Enabled = true;
                txt_filter_mask3.Enabled = true;
                txt_filter_mask4.Enabled = true;
                txt_filter_mask5.Enabled = true;
                chk_filter0.Enabled = true;
                chk_filter1.Enabled = true;
                chk_filter2.Enabled = true;
                chk_filter3.Enabled = true;
                chk_filter4.Enabled = true;
                chk_filter5.Enabled = true;
            }
        }

        //接收非远程帧勾选框状态改变事件
        private void check_feiyuancheng_CheckedChanged(object sender, EventArgs e)
        {
            if (!chk_feiyuancheng.Checked) { chk_yuancheng.Checked = true; }
        }

        //接收远程帧勾选框状态改变事件
        private void check_yuancheng_CheckedChanged(object sender, EventArgs e)
        {
            if (!chk_yuancheng.Checked) { chk_feiyuancheng.Checked = true; }
        }

        private void chk_modbus_def_pkttime_CheckedChanged(object sender, EventArgs e)
        {
            if (!chk_modbus_def_pkttime.Checked)
            {
                txt_packettime.Enabled = false;
            }
            else
            {
                txt_packettime.Enabled = true;
            }
        }
        
        //过滤ID0输入结束事件（检查）
        private void txt_filter_id0_Leave(object sender, EventArgs e)
        {
            if (txt_filter_id0.Text.Length > 8)
            {
                txt_filter_id0.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_id0.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_id0.Text = s + txt_filter_id0.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_id0.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_id0.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_id0.Text = "00000000";
            }
        }

        //过滤ID1输入结束事件（检查）
        private void txt_filter_id1_Leave(object sender, EventArgs e)
        {
            if (txt_filter_id1.Text.Length > 8)
            {
                txt_filter_id1.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_id1.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_id1.Text = s + txt_filter_id1.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_id1.Text, 16) > 0xFFFFFFFF)
                {                  
                    txt_filter_id1.Text = "00000000";
                }
            }
            catch
            {                
                txt_filter_id1.Text = "00000000";
            }
        }

        //过滤ID2输入结束事件（检查）
        private void txt_filter_id2_Leave(object sender, EventArgs e)
        {
            if (txt_filter_id2.Text.Length > 8)
            {
                txt_filter_id2.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_id2.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_id2.Text = s + txt_filter_id2.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_id2.Text, 16) > 0xFFFFFFFF)
                {                   
                    txt_filter_id2.Text = "00000000";
                }
            }
            catch
            {               
                txt_filter_id2.Text = "00000000";
            }
        }

        //过滤ID3输入结束事件（检查）
        private void txt_filter_id3_Leave(object sender, EventArgs e)
        {
            if (txt_filter_id3.Text.Length > 8)
            {
                txt_filter_id3.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_id3.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_id3.Text = s + txt_filter_id3.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_id3.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_id3.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_id3.Text = "00000000";
            }
        }

        //过滤ID4输入结束事件（检查）
        private void txt_filter_id4_Leave(object sender, EventArgs e)
        {
            if (txt_filter_id4.Text.Length > 8)
            {
                txt_filter_id4.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_id4.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_id4.Text = s + txt_filter_id4.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_id4.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_id4.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_id4.Text = "00000000";
            }
        }

        //过滤ID5输入结束事件（检查）
        private void txt_filter_id5_Leave(object sender, EventArgs e)
        {
            if (txt_filter_id5.Text.Length > 8)
            {
                txt_filter_id5.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_id5.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_id5.Text = s + txt_filter_id5.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_id5.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_id5.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_id5.Text = "00000000";
            }
        }

        //过滤MASK0输入结束事件（检查）
        private void txt_filter_mask0_Leave(object sender, EventArgs e)
        {
            if (txt_filter_mask0.Text.Length > 8)
            {
                txt_filter_mask0.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_mask0.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_mask0.Text = s + txt_filter_mask0.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_mask0.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_mask0.Text = "00000000";
                }
            }
            catch
            {                
                txt_filter_mask0.Text = "00000000";
            }
        }

        //过滤MASK1输入结束事件（检查）
        private void txt_filter_mask1_Leave(object sender, EventArgs e)
        {
            if (txt_filter_mask1.Text.Length > 8)
            {
                txt_filter_mask1.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_mask1.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_mask1.Text = s + txt_filter_mask1.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_mask1.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_mask1.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_mask1.Text = "00000000";
            }
        }

        //过滤MASK2输入结束事件（检查）
        private void txt_filter_mask2_Leave(object sender, EventArgs e)
        {
            if (txt_filter_mask2.Text.Length > 8)
            {
                txt_filter_mask2.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_mask2.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_mask2.Text = s + txt_filter_mask2.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_mask2.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_mask2.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_mask2.Text = "00000000";
            }
        }

        //过滤MASK3输入结束事件（检查）
        private void txt_filter_mask3_Leave(object sender, EventArgs e)
        {
            if (txt_filter_mask3.Text.Length > 8)
            {
                txt_filter_mask3.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_mask3.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_mask3.Text = s + txt_filter_mask3.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_mask3.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_mask3.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_mask3.Text = "00000000";
            }
        }

        //过滤MASK4输入结束事件（检查）
        private void txt_filter_mask4_Leave(object sender, EventArgs e)
        {
            if (txt_filter_mask4.Text.Length > 8)
            {
                txt_filter_mask4.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_mask4.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_mask4.Text = s + txt_filter_mask4.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_mask4.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_mask4.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_mask4.Text = "00000000";
            }
        }

        //过滤MASK5输入结束事件（检查）
        private void txt_filter_mask5_Leave(object sender, EventArgs e)
        {
            if (txt_filter_mask5.Text.Length > 8)
            {
                txt_filter_mask5.Text = "00000000";
            }
            string s = "";
            for (int i = txt_filter_mask5.Text.Length; i < 8; i++)
            {
                s += "0";
            }
            txt_filter_mask5.Text = s + txt_filter_mask5.Text;
            try
            {
                if (Convert.ToInt64(txt_filter_mask5.Text, 16) > 0xFFFFFFFF)
                {
                    txt_filter_mask5.Text = "00000000";
                }
            }
            catch
            {
                txt_filter_mask5.Text = "00000000";
            }
        }
                
    }
}
