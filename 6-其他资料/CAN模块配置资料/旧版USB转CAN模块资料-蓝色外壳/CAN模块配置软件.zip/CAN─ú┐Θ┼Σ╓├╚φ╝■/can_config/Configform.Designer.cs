﻿namespace can_config
{
    partial class Configform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mycomm = new System.IO.Ports.SerialPort(this.components);
            this.btn_config = new System.Windows.Forms.Button();
            this.label_Uart_B = new System.Windows.Forms.Label();
            this.label_CAN_B = new System.Windows.Forms.Label();
            this.label_StopBits = new System.Windows.Forms.Label();
            this.label_Parity = new System.Windows.Forms.Label();
            this.cmb_Parity = new System.Windows.Forms.ComboBox();
            this.cmb_StopBits = new System.Windows.Forms.ComboBox();
            this.cmb_BaudRate = new System.Windows.Forms.ComboBox();
            this.label_sendid = new System.Windows.Forms.Label();
            this.txt_sendid = new System.Windows.Forms.TextBox();
            this.cmb_sendtype = new System.Windows.Forms.ComboBox();
            this.label_sendtype = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_packettime = new System.Windows.Forms.TextBox();
            this.chk_biaozhun = new System.Windows.Forms.CheckBox();
            this.chk_kuozhan = new System.Windows.Forms.CheckBox();
            this.chk_yuancheng = new System.Windows.Forms.CheckBox();
            this.chk_feiyuancheng = new System.Windows.Forms.CheckBox();
            this.group_receive = new System.Windows.Forms.GroupBox();
            this.group_send = new System.Windows.Forms.GroupBox();
            this.txt_CAN_B = new System.Windows.Forms.TextBox();
            this.btn_restore = new System.Windows.Forms.Button();
            this.label_COMnumber = new System.Windows.Forms.Label();
            this.label_VersionNumber = new System.Windows.Forms.Label();
            this.label_firmware_version_val = new System.Windows.Forms.Label();
            this.combo_uart = new System.Windows.Forms.ComboBox();
            this.btn_getconfig = new System.Windows.Forms.Button();
            this.cmb_trans_mode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox_empty = new System.Windows.Forms.GroupBox();
            this.groupBox_transaddid = new System.Windows.Forms.GroupBox();
            this.cmb_idpostion = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmb_idlen = new System.Windows.Forms.ComboBox();
            this.groupBox_modbus_Setting = new System.Windows.Forms.GroupBox();
            this.chk_modbus_def_pkttime = new System.Windows.Forms.CheckBox();
            this.groupBox_trans = new System.Windows.Forms.GroupBox();
            this.chk_addinfo = new System.Windows.Forms.CheckBox();
            this.chk_addid = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_filter_id0 = new System.Windows.Forms.TextBox();
            this.txt_filter_mask0 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_filter_id1 = new System.Windows.Forms.TextBox();
            this.txt_filter_mask1 = new System.Windows.Forms.TextBox();
            this.txt_filter_id2 = new System.Windows.Forms.TextBox();
            this.txt_filter_mask2 = new System.Windows.Forms.TextBox();
            this.txt_filter_id3 = new System.Windows.Forms.TextBox();
            this.txt_filter_mask3 = new System.Windows.Forms.TextBox();
            this.txt_filter_id4 = new System.Windows.Forms.TextBox();
            this.txt_filter_mask4 = new System.Windows.Forms.TextBox();
            this.txt_filter_id5 = new System.Windows.Forms.TextBox();
            this.txt_filter_mask5 = new System.Windows.Forms.TextBox();
            this.chk_filter0 = new System.Windows.Forms.CheckBox();
            this.chk_filter1 = new System.Windows.Forms.CheckBox();
            this.chk_filter2 = new System.Windows.Forms.CheckBox();
            this.chk_filter3 = new System.Windows.Forms.CheckBox();
            this.chk_filter4 = new System.Windows.Forms.CheckBox();
            this.chk_filter5 = new System.Windows.Forms.CheckBox();
            this.group_filter = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.group_receive.SuspendLayout();
            this.group_send.SuspendLayout();
            this.groupBox_transaddid.SuspendLayout();
            this.groupBox_modbus_Setting.SuspendLayout();
            this.groupBox_trans.SuspendLayout();
            this.group_filter.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_config
            // 
            this.btn_config.Location = new System.Drawing.Point(426, 493);
            this.btn_config.Margin = new System.Windows.Forms.Padding(2);
            this.btn_config.Name = "btn_config";
            this.btn_config.Size = new System.Drawing.Size(81, 35);
            this.btn_config.TabIndex = 0;
            this.btn_config.Text = "修改配置";
            this.btn_config.UseVisualStyleBackColor = true;
            this.btn_config.Click += new System.EventHandler(this.btn_config_Click);
            // 
            // label_Uart_B
            // 
            this.label_Uart_B.AutoSize = true;
            this.label_Uart_B.Location = new System.Drawing.Point(36, 57);
            this.label_Uart_B.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Uart_B.Name = "label_Uart_B";
            this.label_Uart_B.Size = new System.Drawing.Size(65, 12);
            this.label_Uart_B.TabIndex = 1;
            this.label_Uart_B.Text = "串口波特率";
            // 
            // label_CAN_B
            // 
            this.label_CAN_B.AutoSize = true;
            this.label_CAN_B.Location = new System.Drawing.Point(258, 57);
            this.label_CAN_B.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_CAN_B.Name = "label_CAN_B";
            this.label_CAN_B.Size = new System.Drawing.Size(59, 12);
            this.label_CAN_B.TabIndex = 2;
            this.label_CAN_B.Text = "CAN波特率";
            // 
            // label_StopBits
            // 
            this.label_StopBits.AutoSize = true;
            this.label_StopBits.Location = new System.Drawing.Point(48, 96);
            this.label_StopBits.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_StopBits.Name = "label_StopBits";
            this.label_StopBits.Size = new System.Drawing.Size(41, 12);
            this.label_StopBits.TabIndex = 3;
            this.label_StopBits.Text = "停止位";
            // 
            // label_Parity
            // 
            this.label_Parity.AutoSize = true;
            this.label_Parity.Location = new System.Drawing.Point(267, 96);
            this.label_Parity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Parity.Name = "label_Parity";
            this.label_Parity.Size = new System.Drawing.Size(41, 12);
            this.label_Parity.TabIndex = 4;
            this.label_Parity.Text = "校验位";
            // 
            // cmb_Parity
            // 
            this.cmb_Parity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Parity.FormattingEnabled = true;
            this.cmb_Parity.Items.AddRange(new object[] {
            "无校验",
            "奇校验",
            "偶校验"});
            this.cmb_Parity.Location = new System.Drawing.Point(342, 92);
            this.cmb_Parity.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_Parity.Name = "cmb_Parity";
            this.cmb_Parity.Size = new System.Drawing.Size(93, 20);
            this.cmb_Parity.TabIndex = 13;
            // 
            // cmb_StopBits
            // 
            this.cmb_StopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_StopBits.FormattingEnabled = true;
            this.cmb_StopBits.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.cmb_StopBits.Location = new System.Drawing.Point(120, 92);
            this.cmb_StopBits.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_StopBits.Name = "cmb_StopBits";
            this.cmb_StopBits.Size = new System.Drawing.Size(93, 20);
            this.cmb_StopBits.TabIndex = 12;
            // 
            // cmb_BaudRate
            // 
            this.cmb_BaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_BaudRate.FormattingEnabled = true;
            this.cmb_BaudRate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800"});
            this.cmb_BaudRate.Location = new System.Drawing.Point(120, 53);
            this.cmb_BaudRate.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_BaudRate.Name = "cmb_BaudRate";
            this.cmb_BaudRate.Size = new System.Drawing.Size(93, 20);
            this.cmb_BaudRate.TabIndex = 10;
            // 
            // label_sendid
            // 
            this.label_sendid.AutoSize = true;
            this.label_sendid.Location = new System.Drawing.Point(15, 32);
            this.label_sendid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_sendid.Name = "label_sendid";
            this.label_sendid.Size = new System.Drawing.Size(65, 12);
            this.label_sendid.TabIndex = 14;
            this.label_sendid.Text = "发送报文ID";
            // 
            // txt_sendid
            // 
            this.txt_sendid.Location = new System.Drawing.Point(107, 28);
            this.txt_sendid.Margin = new System.Windows.Forms.Padding(2);
            this.txt_sendid.Name = "txt_sendid";
            this.txt_sendid.Size = new System.Drawing.Size(92, 21);
            this.txt_sendid.TabIndex = 15;
            this.txt_sendid.Text = "00000000";
            this.txt_sendid.Leave += new System.EventHandler(this.txt_sendid_Leave);
            // 
            // cmb_sendtype
            // 
            this.cmb_sendtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_sendtype.FormattingEnabled = true;
            this.cmb_sendtype.Items.AddRange(new object[] {
            "标准帧",
            "扩展帧"});
            this.cmb_sendtype.Location = new System.Drawing.Point(107, 59);
            this.cmb_sendtype.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_sendtype.Name = "cmb_sendtype";
            this.cmb_sendtype.Size = new System.Drawing.Size(92, 20);
            this.cmb_sendtype.TabIndex = 16;
            this.cmb_sendtype.SelectedIndexChanged += new System.EventHandler(this.combo_sendtype_SelectedIndexChanged);
            // 
            // label_sendtype
            // 
            this.label_sendtype.AutoSize = true;
            this.label_sendtype.Location = new System.Drawing.Point(15, 63);
            this.label_sendtype.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_sendtype.Name = "label_sendtype";
            this.label_sendtype.Size = new System.Drawing.Size(77, 12);
            this.label_sendtype.TabIndex = 17;
            this.label_sendtype.Text = "发送报文类型";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 94);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "分包间隔（ms）";
            // 
            // txt_packettime
            // 
            this.txt_packettime.Location = new System.Drawing.Point(108, 90);
            this.txt_packettime.Margin = new System.Windows.Forms.Padding(2);
            this.txt_packettime.Name = "txt_packettime";
            this.txt_packettime.Size = new System.Drawing.Size(91, 21);
            this.txt_packettime.TabIndex = 19;
            this.txt_packettime.Text = "0";
            this.txt_packettime.Leave += new System.EventHandler(this.txt_packettime_Leave);
            // 
            // chk_biaozhun
            // 
            this.chk_biaozhun.AutoSize = true;
            this.chk_biaozhun.Location = new System.Drawing.Point(19, 26);
            this.chk_biaozhun.Margin = new System.Windows.Forms.Padding(2);
            this.chk_biaozhun.Name = "chk_biaozhun";
            this.chk_biaozhun.Size = new System.Drawing.Size(60, 16);
            this.chk_biaozhun.TabIndex = 22;
            this.chk_biaozhun.Text = "标准帧";
            this.chk_biaozhun.UseVisualStyleBackColor = true;
            this.chk_biaozhun.CheckedChanged += new System.EventHandler(this.check_biaozhun_CheckedChanged);
            // 
            // chk_kuozhan
            // 
            this.chk_kuozhan.AutoSize = true;
            this.chk_kuozhan.Location = new System.Drawing.Point(129, 26);
            this.chk_kuozhan.Margin = new System.Windows.Forms.Padding(2);
            this.chk_kuozhan.Name = "chk_kuozhan";
            this.chk_kuozhan.Size = new System.Drawing.Size(60, 16);
            this.chk_kuozhan.TabIndex = 23;
            this.chk_kuozhan.Text = "扩展帧";
            this.chk_kuozhan.UseVisualStyleBackColor = true;
            this.chk_kuozhan.CheckedChanged += new System.EventHandler(this.check_kuozhan_CheckedChanged);
            // 
            // chk_yuancheng
            // 
            this.chk_yuancheng.AutoSize = true;
            this.chk_yuancheng.Location = new System.Drawing.Point(129, 56);
            this.chk_yuancheng.Margin = new System.Windows.Forms.Padding(2);
            this.chk_yuancheng.Name = "chk_yuancheng";
            this.chk_yuancheng.Size = new System.Drawing.Size(60, 16);
            this.chk_yuancheng.TabIndex = 24;
            this.chk_yuancheng.Text = "远程帧";
            this.chk_yuancheng.UseVisualStyleBackColor = true;
            this.chk_yuancheng.CheckedChanged += new System.EventHandler(this.check_yuancheng_CheckedChanged);
            // 
            // chk_feiyuancheng
            // 
            this.chk_feiyuancheng.AutoSize = true;
            this.chk_feiyuancheng.Location = new System.Drawing.Point(19, 56);
            this.chk_feiyuancheng.Margin = new System.Windows.Forms.Padding(2);
            this.chk_feiyuancheng.Name = "chk_feiyuancheng";
            this.chk_feiyuancheng.Size = new System.Drawing.Size(84, 16);
            this.chk_feiyuancheng.TabIndex = 25;
            this.chk_feiyuancheng.Text = "非远程帧帧";
            this.chk_feiyuancheng.UseVisualStyleBackColor = true;
            this.chk_feiyuancheng.CheckedChanged += new System.EventHandler(this.check_feiyuancheng_CheckedChanged);
            // 
            // group_receive
            // 
            this.group_receive.Controls.Add(this.chk_feiyuancheng);
            this.group_receive.Controls.Add(this.chk_biaozhun);
            this.group_receive.Controls.Add(this.chk_kuozhan);
            this.group_receive.Controls.Add(this.chk_yuancheng);
            this.group_receive.Location = new System.Drawing.Point(30, 384);
            this.group_receive.Margin = new System.Windows.Forms.Padding(2);
            this.group_receive.Name = "group_receive";
            this.group_receive.Padding = new System.Windows.Forms.Padding(2);
            this.group_receive.Size = new System.Drawing.Size(220, 95);
            this.group_receive.TabIndex = 30;
            this.group_receive.TabStop = false;
            this.group_receive.Text = "接收设置";
            // 
            // group_send
            // 
            this.group_send.Controls.Add(this.cmb_sendtype);
            this.group_send.Controls.Add(this.label1);
            this.group_send.Controls.Add(this.txt_sendid);
            this.group_send.Controls.Add(this.label_sendtype);
            this.group_send.Controls.Add(this.txt_packettime);
            this.group_send.Controls.Add(this.label_sendid);
            this.group_send.Location = new System.Drawing.Point(30, 236);
            this.group_send.Margin = new System.Windows.Forms.Padding(2);
            this.group_send.Name = "group_send";
            this.group_send.Padding = new System.Windows.Forms.Padding(2);
            this.group_send.Size = new System.Drawing.Size(220, 130);
            this.group_send.TabIndex = 31;
            this.group_send.TabStop = false;
            this.group_send.Text = "发送设置";
            // 
            // txt_CAN_B
            // 
            this.txt_CAN_B.Location = new System.Drawing.Point(342, 53);
            this.txt_CAN_B.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CAN_B.Name = "txt_CAN_B";
            this.txt_CAN_B.Size = new System.Drawing.Size(93, 21);
            this.txt_CAN_B.TabIndex = 32;
            this.txt_CAN_B.Text = "1000.0";
            this.txt_CAN_B.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_CAN_B_KeyDown);
            this.txt_CAN_B.Leave += new System.EventHandler(this.txt_CAN_B_Leave);
            // 
            // btn_restore
            // 
            this.btn_restore.Location = new System.Drawing.Point(237, 493);
            this.btn_restore.Margin = new System.Windows.Forms.Padding(2);
            this.btn_restore.Name = "btn_restore";
            this.btn_restore.Size = new System.Drawing.Size(76, 35);
            this.btn_restore.TabIndex = 33;
            this.btn_restore.Text = "恢复默认";
            this.btn_restore.UseVisualStyleBackColor = true;
            this.btn_restore.Click += new System.EventHandler(this.btn_restore_Click);
            // 
            // label_COMnumber
            // 
            this.label_COMnumber.BackColor = System.Drawing.Color.Transparent;
            this.label_COMnumber.Location = new System.Drawing.Point(36, 19);
            this.label_COMnumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_COMnumber.Name = "label_COMnumber";
            this.label_COMnumber.Size = new System.Drawing.Size(42, 17);
            this.label_COMnumber.TabIndex = 35;
            this.label_COMnumber.Text = "串口号";
            this.label_COMnumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_VersionNumber
            // 
            this.label_VersionNumber.AutoSize = true;
            this.label_VersionNumber.BackColor = System.Drawing.Color.Transparent;
            this.label_VersionNumber.Location = new System.Drawing.Point(258, 19);
            this.label_VersionNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_VersionNumber.Name = "label_VersionNumber";
            this.label_VersionNumber.Size = new System.Drawing.Size(77, 12);
            this.label_VersionNumber.TabIndex = 35;
            this.label_VersionNumber.Text = "固件版本号：";
            this.label_VersionNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_firmware_version_val
            // 
            this.label_firmware_version_val.BackColor = System.Drawing.Color.Transparent;
            this.label_firmware_version_val.Location = new System.Drawing.Point(330, 17);
            this.label_firmware_version_val.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_firmware_version_val.Name = "label_firmware_version_val";
            this.label_firmware_version_val.Size = new System.Drawing.Size(42, 17);
            this.label_firmware_version_val.TabIndex = 35;
            this.label_firmware_version_val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // combo_uart
            // 
            this.combo_uart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_uart.FormattingEnabled = true;
            this.combo_uart.Location = new System.Drawing.Point(120, 17);
            this.combo_uart.Margin = new System.Windows.Forms.Padding(2);
            this.combo_uart.Name = "combo_uart";
            this.combo_uart.Size = new System.Drawing.Size(76, 20);
            this.combo_uart.TabIndex = 34;
            this.combo_uart.Click += new System.EventHandler(this.combo_uart_Click);
            // 
            // btn_getconfig
            // 
            this.btn_getconfig.AutoSize = true;
            this.btn_getconfig.Location = new System.Drawing.Point(57, 493);
            this.btn_getconfig.Margin = new System.Windows.Forms.Padding(2);
            this.btn_getconfig.Name = "btn_getconfig";
            this.btn_getconfig.Size = new System.Drawing.Size(87, 35);
            this.btn_getconfig.TabIndex = 36;
            this.btn_getconfig.Text = "获取当前状态";
            this.btn_getconfig.UseVisualStyleBackColor = true;
            this.btn_getconfig.Click += new System.EventHandler(this.btn_getconfig_Click);
            // 
            // cmb_trans_mode
            // 
            this.cmb_trans_mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_trans_mode.FormattingEnabled = true;
            this.cmb_trans_mode.Items.AddRange(new object[] {
            "透传模式",
            "包模式",
            "透传带标识模式",
            "MODBUS模式",
            "格式转换"});
            this.cmb_trans_mode.Location = new System.Drawing.Point(120, 131);
            this.cmb_trans_mode.Name = "cmb_trans_mode";
            this.cmb_trans_mode.Size = new System.Drawing.Size(121, 20);
            this.cmb_trans_mode.TabIndex = 38;
            this.cmb_trans_mode.SelectedIndexChanged += new System.EventHandler(this.cmb_trans_mode_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 135);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 39;
            this.label4.Text = "转换模式";
            // 
            // groupBox_empty
            // 
            this.groupBox_empty.Location = new System.Drawing.Point(30, 161);
            this.groupBox_empty.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_empty.Name = "groupBox_empty";
            this.groupBox_empty.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_empty.Size = new System.Drawing.Size(506, 60);
            this.groupBox_empty.TabIndex = 44;
            this.groupBox_empty.TabStop = false;
            this.groupBox_empty.Text = "转换设置";
            // 
            // groupBox_transaddid
            // 
            this.groupBox_transaddid.Controls.Add(this.cmb_idpostion);
            this.groupBox_transaddid.Controls.Add(this.label6);
            this.groupBox_transaddid.Controls.Add(this.label7);
            this.groupBox_transaddid.Controls.Add(this.cmb_idlen);
            this.groupBox_transaddid.Location = new System.Drawing.Point(30, 161);
            this.groupBox_transaddid.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_transaddid.Name = "groupBox_transaddid";
            this.groupBox_transaddid.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_transaddid.Size = new System.Drawing.Size(506, 60);
            this.groupBox_transaddid.TabIndex = 45;
            this.groupBox_transaddid.TabStop = false;
            this.groupBox_transaddid.Text = "转换设置";
            // 
            // cmb_idpostion
            // 
            this.cmb_idpostion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_idpostion.FormattingEnabled = true;
            this.cmb_idpostion.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.cmb_idpostion.Location = new System.Drawing.Point(88, 25);
            this.cmb_idpostion.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_idpostion.Name = "cmb_idpostion";
            this.cmb_idpostion.Size = new System.Drawing.Size(93, 20);
            this.cmb_idpostion.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(248, 29);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 41;
            this.label6.Text = "ID长度";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 29);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 37;
            this.label7.Text = "ID位置";
            // 
            // cmb_idlen
            // 
            this.cmb_idlen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_idlen.FormattingEnabled = true;
            this.cmb_idlen.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cmb_idlen.Location = new System.Drawing.Point(318, 25);
            this.cmb_idlen.Margin = new System.Windows.Forms.Padding(2);
            this.cmb_idlen.Name = "cmb_idlen";
            this.cmb_idlen.Size = new System.Drawing.Size(93, 20);
            this.cmb_idlen.TabIndex = 42;
            // 
            // groupBox_modbus_Setting
            // 
            this.groupBox_modbus_Setting.Controls.Add(this.chk_modbus_def_pkttime);
            this.groupBox_modbus_Setting.Location = new System.Drawing.Point(30, 161);
            this.groupBox_modbus_Setting.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_modbus_Setting.Name = "groupBox_modbus_Setting";
            this.groupBox_modbus_Setting.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_modbus_Setting.Size = new System.Drawing.Size(506, 60);
            this.groupBox_modbus_Setting.TabIndex = 45;
            this.groupBox_modbus_Setting.TabStop = false;
            this.groupBox_modbus_Setting.Text = "转换设置";
            // 
            // chk_modbus_def_pkttime
            // 
            this.chk_modbus_def_pkttime.AutoSize = true;
            this.chk_modbus_def_pkttime.Location = new System.Drawing.Point(74, 27);
            this.chk_modbus_def_pkttime.Margin = new System.Windows.Forms.Padding(2);
            this.chk_modbus_def_pkttime.Name = "chk_modbus_def_pkttime";
            this.chk_modbus_def_pkttime.Size = new System.Drawing.Size(324, 16);
            this.chk_modbus_def_pkttime.TabIndex = 37;
            this.chk_modbus_def_pkttime.Text = "自定义MODBUS分包间隔（0表示默认的3.5字符分包间隔）";
            this.chk_modbus_def_pkttime.UseVisualStyleBackColor = true;
            this.chk_modbus_def_pkttime.CheckedChanged += new System.EventHandler(this.chk_modbus_def_pkttime_CheckedChanged);
            // 
            // groupBox_trans
            // 
            this.groupBox_trans.Controls.Add(this.chk_addinfo);
            this.groupBox_trans.Controls.Add(this.chk_addid);
            this.groupBox_trans.Location = new System.Drawing.Point(30, 161);
            this.groupBox_trans.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_trans.Name = "groupBox_trans";
            this.groupBox_trans.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_trans.Size = new System.Drawing.Size(506, 60);
            this.groupBox_trans.TabIndex = 46;
            this.groupBox_trans.TabStop = false;
            this.groupBox_trans.Text = "转换设置";
            // 
            // chk_addinfo
            // 
            this.chk_addinfo.AutoSize = true;
            this.chk_addinfo.Location = new System.Drawing.Point(74, 27);
            this.chk_addinfo.Margin = new System.Windows.Forms.Padding(2);
            this.chk_addinfo.Name = "chk_addinfo";
            this.chk_addinfo.Size = new System.Drawing.Size(84, 16);
            this.chk_addinfo.TabIndex = 40;
            this.chk_addinfo.Text = "添加帧信息";
            this.chk_addinfo.UseVisualStyleBackColor = true;
            // 
            // chk_addid
            // 
            this.chk_addid.AutoSize = true;
            this.chk_addid.Location = new System.Drawing.Point(293, 27);
            this.chk_addid.Margin = new System.Windows.Forms.Padding(2);
            this.chk_addid.Name = "chk_addid";
            this.chk_addid.Size = new System.Drawing.Size(60, 16);
            this.chk_addid.TabIndex = 39;
            this.chk_addid.Text = "添加ID";
            this.chk_addid.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 29);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 47;
            this.label2.Text = "ID";
            // 
            // txt_filter_id0
            // 
            this.txt_filter_id0.Location = new System.Drawing.Point(23, 58);
            this.txt_filter_id0.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_id0.Name = "txt_filter_id0";
            this.txt_filter_id0.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_id0.TabIndex = 48;
            this.txt_filter_id0.Text = "00000000";
            this.txt_filter_id0.Leave += new System.EventHandler(this.txt_filter_id0_Leave);
            // 
            // txt_filter_mask0
            // 
            this.txt_filter_mask0.Location = new System.Drawing.Point(128, 58);
            this.txt_filter_mask0.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_mask0.Name = "txt_filter_mask0";
            this.txt_filter_mask0.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_mask0.TabIndex = 50;
            this.txt_filter_mask0.Text = "00000000";
            this.txt_filter_mask0.Leave += new System.EventHandler(this.txt_filter_mask0_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(158, 29);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 49;
            this.label3.Text = "MASK";
            // 
            // txt_filter_id1
            // 
            this.txt_filter_id1.Location = new System.Drawing.Point(23, 87);
            this.txt_filter_id1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_id1.Name = "txt_filter_id1";
            this.txt_filter_id1.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_id1.TabIndex = 51;
            this.txt_filter_id1.Text = "00000000";
            this.txt_filter_id1.Leave += new System.EventHandler(this.txt_filter_id1_Leave);
            // 
            // txt_filter_mask1
            // 
            this.txt_filter_mask1.Location = new System.Drawing.Point(128, 87);
            this.txt_filter_mask1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_mask1.Name = "txt_filter_mask1";
            this.txt_filter_mask1.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_mask1.TabIndex = 52;
            this.txt_filter_mask1.Text = "00000000";
            this.txt_filter_mask1.Leave += new System.EventHandler(this.txt_filter_mask1_Leave);
            // 
            // txt_filter_id2
            // 
            this.txt_filter_id2.Location = new System.Drawing.Point(23, 116);
            this.txt_filter_id2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_id2.Name = "txt_filter_id2";
            this.txt_filter_id2.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_id2.TabIndex = 53;
            this.txt_filter_id2.Text = "00000000";
            this.txt_filter_id2.Leave += new System.EventHandler(this.txt_filter_id2_Leave);
            // 
            // txt_filter_mask2
            // 
            this.txt_filter_mask2.Location = new System.Drawing.Point(128, 116);
            this.txt_filter_mask2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_mask2.Name = "txt_filter_mask2";
            this.txt_filter_mask2.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_mask2.TabIndex = 54;
            this.txt_filter_mask2.Text = "00000000";
            this.txt_filter_mask2.Leave += new System.EventHandler(this.txt_filter_mask2_Leave);
            // 
            // txt_filter_id3
            // 
            this.txt_filter_id3.Location = new System.Drawing.Point(23, 145);
            this.txt_filter_id3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_id3.Name = "txt_filter_id3";
            this.txt_filter_id3.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_id3.TabIndex = 55;
            this.txt_filter_id3.Text = "00000000";
            this.txt_filter_id3.Leave += new System.EventHandler(this.txt_filter_id3_Leave);
            // 
            // txt_filter_mask3
            // 
            this.txt_filter_mask3.Location = new System.Drawing.Point(128, 145);
            this.txt_filter_mask3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_mask3.Name = "txt_filter_mask3";
            this.txt_filter_mask3.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_mask3.TabIndex = 56;
            this.txt_filter_mask3.Text = "00000000";
            this.txt_filter_mask3.Leave += new System.EventHandler(this.txt_filter_mask3_Leave);
            // 
            // txt_filter_id4
            // 
            this.txt_filter_id4.Location = new System.Drawing.Point(23, 174);
            this.txt_filter_id4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_id4.Name = "txt_filter_id4";
            this.txt_filter_id4.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_id4.TabIndex = 57;
            this.txt_filter_id4.Text = "00000000";
            this.txt_filter_id4.Leave += new System.EventHandler(this.txt_filter_id4_Leave);
            // 
            // txt_filter_mask4
            // 
            this.txt_filter_mask4.Location = new System.Drawing.Point(128, 174);
            this.txt_filter_mask4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_mask4.Name = "txt_filter_mask4";
            this.txt_filter_mask4.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_mask4.TabIndex = 58;
            this.txt_filter_mask4.Text = "00000000";
            this.txt_filter_mask4.Leave += new System.EventHandler(this.txt_filter_mask4_Leave);
            // 
            // txt_filter_id5
            // 
            this.txt_filter_id5.Location = new System.Drawing.Point(23, 203);
            this.txt_filter_id5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_id5.Name = "txt_filter_id5";
            this.txt_filter_id5.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_id5.TabIndex = 59;
            this.txt_filter_id5.Text = "00000000";
            this.txt_filter_id5.Leave += new System.EventHandler(this.txt_filter_id5_Leave);
            // 
            // txt_filter_mask5
            // 
            this.txt_filter_mask5.Location = new System.Drawing.Point(128, 203);
            this.txt_filter_mask5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_filter_mask5.Name = "txt_filter_mask5";
            this.txt_filter_mask5.Size = new System.Drawing.Size(92, 21);
            this.txt_filter_mask5.TabIndex = 60;
            this.txt_filter_mask5.Text = "00000000";
            this.txt_filter_mask5.Leave += new System.EventHandler(this.txt_filter_mask5_Leave);
            // 
            // chk_filter0
            // 
            this.chk_filter0.AutoSize = true;
            this.chk_filter0.Checked = true;
            this.chk_filter0.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_filter0.Location = new System.Drawing.Point(234, 61);
            this.chk_filter0.Name = "chk_filter0";
            this.chk_filter0.Size = new System.Drawing.Size(15, 14);
            this.chk_filter0.TabIndex = 61;
            this.chk_filter0.UseVisualStyleBackColor = true;
            // 
            // chk_filter1
            // 
            this.chk_filter1.AutoSize = true;
            this.chk_filter1.Location = new System.Drawing.Point(234, 90);
            this.chk_filter1.Name = "chk_filter1";
            this.chk_filter1.Size = new System.Drawing.Size(15, 14);
            this.chk_filter1.TabIndex = 62;
            this.chk_filter1.UseVisualStyleBackColor = true;
            // 
            // chk_filter2
            // 
            this.chk_filter2.AutoSize = true;
            this.chk_filter2.Location = new System.Drawing.Point(234, 119);
            this.chk_filter2.Name = "chk_filter2";
            this.chk_filter2.Size = new System.Drawing.Size(15, 14);
            this.chk_filter2.TabIndex = 63;
            this.chk_filter2.UseVisualStyleBackColor = true;
            // 
            // chk_filter3
            // 
            this.chk_filter3.AutoSize = true;
            this.chk_filter3.Location = new System.Drawing.Point(234, 148);
            this.chk_filter3.Name = "chk_filter3";
            this.chk_filter3.Size = new System.Drawing.Size(15, 14);
            this.chk_filter3.TabIndex = 64;
            this.chk_filter3.UseVisualStyleBackColor = true;
            // 
            // chk_filter4
            // 
            this.chk_filter4.AutoSize = true;
            this.chk_filter4.Location = new System.Drawing.Point(234, 177);
            this.chk_filter4.Name = "chk_filter4";
            this.chk_filter4.Size = new System.Drawing.Size(15, 14);
            this.chk_filter4.TabIndex = 65;
            this.chk_filter4.UseVisualStyleBackColor = true;
            // 
            // chk_filter5
            // 
            this.chk_filter5.AutoSize = true;
            this.chk_filter5.Location = new System.Drawing.Point(234, 206);
            this.chk_filter5.Name = "chk_filter5";
            this.chk_filter5.Size = new System.Drawing.Size(15, 14);
            this.chk_filter5.TabIndex = 66;
            this.chk_filter5.UseVisualStyleBackColor = true;
            // 
            // group_filter
            // 
            this.group_filter.Controls.Add(this.label5);
            this.group_filter.Controls.Add(this.label2);
            this.group_filter.Controls.Add(this.chk_filter5);
            this.group_filter.Controls.Add(this.label3);
            this.group_filter.Controls.Add(this.chk_filter4);
            this.group_filter.Controls.Add(this.txt_filter_mask0);
            this.group_filter.Controls.Add(this.chk_filter3);
            this.group_filter.Controls.Add(this.txt_filter_id0);
            this.group_filter.Controls.Add(this.chk_filter2);
            this.group_filter.Controls.Add(this.txt_filter_mask1);
            this.group_filter.Controls.Add(this.chk_filter1);
            this.group_filter.Controls.Add(this.txt_filter_id1);
            this.group_filter.Controls.Add(this.chk_filter0);
            this.group_filter.Controls.Add(this.txt_filter_mask2);
            this.group_filter.Controls.Add(this.txt_filter_id5);
            this.group_filter.Controls.Add(this.txt_filter_id2);
            this.group_filter.Controls.Add(this.txt_filter_mask5);
            this.group_filter.Controls.Add(this.txt_filter_mask3);
            this.group_filter.Controls.Add(this.txt_filter_id4);
            this.group_filter.Controls.Add(this.txt_filter_id3);
            this.group_filter.Controls.Add(this.txt_filter_mask4);
            this.group_filter.Location = new System.Drawing.Point(266, 236);
            this.group_filter.Name = "group_filter";
            this.group_filter.Size = new System.Drawing.Size(270, 243);
            this.group_filter.TabIndex = 67;
            this.group_filter.TabStop = false;
            this.group_filter.Text = "过滤设置";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(227, 29);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 68;
            this.label5.Text = "使能";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(439, 57);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 68;
            this.label8.Text = "Kbps";
            // 
            // Configform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(557, 543);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.group_filter);
            this.Controls.Add(this.groupBox_trans);
            this.Controls.Add(this.groupBox_transaddid);
            this.Controls.Add(this.groupBox_modbus_Setting);
            this.Controls.Add(this.groupBox_empty);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmb_trans_mode);
            this.Controls.Add(this.btn_getconfig);
            this.Controls.Add(this.label_COMnumber);
            this.Controls.Add(this.label_VersionNumber);
            this.Controls.Add(this.label_firmware_version_val);
            this.Controls.Add(this.combo_uart);
            this.Controls.Add(this.btn_restore);
            this.Controls.Add(this.txt_CAN_B);
            this.Controls.Add(this.group_send);
            this.Controls.Add(this.group_receive);
            this.Controls.Add(this.cmb_Parity);
            this.Controls.Add(this.cmb_StopBits);
            this.Controls.Add(this.cmb_BaudRate);
            this.Controls.Add(this.label_Parity);
            this.Controls.Add(this.label_StopBits);
            this.Controls.Add(this.label_CAN_B);
            this.Controls.Add(this.label_Uart_B);
            this.Controls.Add(this.btn_config);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "Configform";
            this.ShowIcon = false;
            this.Text = "CAN模块配置软件";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Configform_FormClosing);
            this.Load += new System.EventHandler(this.Configform_Load);
            this.group_receive.ResumeLayout(false);
            this.group_receive.PerformLayout();
            this.group_send.ResumeLayout(false);
            this.group_send.PerformLayout();
            this.groupBox_transaddid.ResumeLayout(false);
            this.groupBox_transaddid.PerformLayout();
            this.groupBox_modbus_Setting.ResumeLayout(false);
            this.groupBox_modbus_Setting.PerformLayout();
            this.groupBox_trans.ResumeLayout(false);
            this.groupBox_trans.PerformLayout();
            this.group_filter.ResumeLayout(false);
            this.group_filter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort mycomm;
        private System.Windows.Forms.Button btn_config;
        private System.Windows.Forms.Label label_Uart_B;
        private System.Windows.Forms.Label label_CAN_B;
        private System.Windows.Forms.Label label_StopBits;
        private System.Windows.Forms.Label label_Parity;
        private System.Windows.Forms.ComboBox cmb_Parity;
        private System.Windows.Forms.ComboBox cmb_StopBits;
        private System.Windows.Forms.ComboBox cmb_BaudRate;
        private System.Windows.Forms.Label label_sendid;
        private System.Windows.Forms.TextBox txt_sendid;
        private System.Windows.Forms.ComboBox cmb_sendtype;
        private System.Windows.Forms.Label label_sendtype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_packettime;
        private System.Windows.Forms.CheckBox chk_biaozhun;
        private System.Windows.Forms.CheckBox chk_kuozhan;
        private System.Windows.Forms.CheckBox chk_yuancheng;
        private System.Windows.Forms.CheckBox chk_feiyuancheng;
        private System.Windows.Forms.GroupBox group_receive;
        private System.Windows.Forms.GroupBox group_send;
        private System.Windows.Forms.TextBox txt_CAN_B;
        private System.Windows.Forms.Button btn_restore;
        private System.Windows.Forms.Label label_COMnumber;
        private System.Windows.Forms.Label label_VersionNumber;
        private System.Windows.Forms.Label label_firmware_version_val;        
        private System.Windows.Forms.ComboBox combo_uart;
        private System.Windows.Forms.Button btn_getconfig;
        private System.Windows.Forms.ComboBox cmb_trans_mode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox_empty;
        private System.Windows.Forms.GroupBox groupBox_transaddid;
        private System.Windows.Forms.GroupBox groupBox_modbus_Setting;        
        private System.Windows.Forms.ComboBox cmb_idpostion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chk_modbus_def_pkttime;        
        private System.Windows.Forms.ComboBox cmb_idlen;
        private System.Windows.Forms.GroupBox groupBox_trans;
        private System.Windows.Forms.CheckBox chk_addinfo;
        private System.Windows.Forms.CheckBox chk_addid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_filter_id0;
        private System.Windows.Forms.TextBox txt_filter_mask0;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_filter_id1;
        private System.Windows.Forms.TextBox txt_filter_mask1;
        private System.Windows.Forms.TextBox txt_filter_id2;
        private System.Windows.Forms.TextBox txt_filter_mask2;
        private System.Windows.Forms.TextBox txt_filter_id3;
        private System.Windows.Forms.TextBox txt_filter_mask3;
        private System.Windows.Forms.TextBox txt_filter_id4;
        private System.Windows.Forms.TextBox txt_filter_mask4;
        private System.Windows.Forms.TextBox txt_filter_id5;
        private System.Windows.Forms.TextBox txt_filter_mask5;
        private System.Windows.Forms.CheckBox chk_filter0;
        private System.Windows.Forms.CheckBox chk_filter1;
        private System.Windows.Forms.CheckBox chk_filter2;
        private System.Windows.Forms.CheckBox chk_filter3;
        private System.Windows.Forms.CheckBox chk_filter4;
        private System.Windows.Forms.CheckBox chk_filter5;
        private System.Windows.Forms.GroupBox group_filter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
    }
}